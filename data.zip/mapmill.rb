#!/usr/bin/env ruby

require 'pry'
require 'rubyXL'
require 'csv'
require "i18n"
require 'json'

# Arquivo dbf original
source_dbf = "55mu2500gsr_orig.csv"

# Dados dos municípios
# ./dados.xlsx
acao_data = "dados.xlsx"

# Localidades
# csv, separacao por tabulacao
location_csv = "./BR_Localidades_2010_v1.csv"

# Estados
# csv, separacao por tabulacao
states_csv = "./estados_2010.csv"



class MapImporter
	def initialize(source_dbf, acao_data, location_csv, states_csv)
		
		@states_obj = []
		@cities_obj = []
		@output_dbf = nil
		@first_column = 3
		@cols = 0
		self.import_data(source_dbf, acao_data, location_csv, states_csv)
	end

	def import_data(source_dbf, acao_data, location_csv, states_csv)
		puts "Carregando DBF Original"
		@source_dbf = CSV.read(source_dbf,  { :col_sep => "\t", :headers => true }) 
		
		
		puts "Carregando dados da Acao Educativa"
		@acao_data = RubyXL::Parser.parse(acao_data)[0].extract_data
		@cols = @acao_data.first.count - 3


		puts "Carregando unidades federativas"
		@states_csv = CSV.read(states_csv,  { :col_sep => "\t", :headers => true  }) 

		puts "Carregando coordenadas de localizacao"
		@location_csv = CSV.read(location_csv,  { :col_sep => "\t"})

		self.create_coord_dict

		true
	end
	
	def create_coord_dict
		@coords = {}
		@location_csv.each do |row|
			@coords[row[9]] = {lat: row[-3], lng: row[-4]}
		end
		

	end

	def show
		#puts @source_dbf
	end

	def create_states_json
		puts "Criando estados"
		s = @states_csv.to_a
		s.shift
		@states_obj = s.map{|r| {nome: r[0], sigla: r[1], cod: r[2], lat: 0.0001, lng: 0.0001}}		
	end



	def get_states_location
		puts "Pegando localização dos estados"
		@states_obj.each{|s| self.get_state_avg_point(s) }
	end

	def tr(str)
		str.tr(
		"ÀÁÂÃÄÅàáâãäåĀāĂăĄąÇçĆćĈĉĊċČčÐðĎďĐđÈÉÊËèéêëĒēĔĕĖėĘęĚěĜĝĞğĠġĢģĤĥĦħÌÍÎÏìíîïĨĩĪīĬĭĮįİıĴĵĶķĸĹĺĻļĽľĿŀŁłÑñŃńŅņŇňŉŊŋÒÓÔÕÖØòóôõöøŌōŎŏŐőŔŕŖŗŘřŚśŜŝŞşŠšſŢţŤťŦŧÙÚÛÜùúûüŨũŪūŬŭŮůŰűŲųŴŵÝýÿŶŷŸŹźŻżŽž",
		"AAAAAAaaaaaaAaAaAaCcCcCcCcCcDdDdDdEEEEeeeeEeEeEeEeEeGgGgGgGgHhHhIIIIiiiiIiIiIiIiIiJjKkkLlLlLlLlLlNnNnNnNnnNnOOOOOOooooooOoOoOoRrRrRrSsSsSsSssTtTtTtUUUUuuuuUuUuUuUuUuUuWwYyyYyYZzZzZz")
	end

	def get_state_avg_point(state)
		nome = tr(state[:nome])
		l = @location_csv.select{|s| s[16]=="CIDADE"}.select{|s| tr(s[13])==nome.upcase}
		arr_lat = l.map{|s| s[-3].gsub(",", ".").to_f}
		lat = arr_lat.inject{ |sum, el| sum + el }.to_f / arr_lat.size
		arr_lng = l.map{|s| s[-4].gsub(",", ".").to_f}
		lng = arr_lng.inject{ |sum, el| sum + el }.to_f / arr_lng.size
		
		state[:lat] = lat
		state[:lng] = lng
		puts "Selecionando ponto médio para #{nome} -> #{lat}, #{lng}"
	end

	def work
		self.create_states_json
		#self.get_states_location
		merge_acao_data	
		export_states_json
		export_cities_json
		puts "Pronto!"
	end

	def merge_acao_data
		puts "Juntando dados à planilha principal"
		a1 = @source_dbf.to_a
		header = a1.shift
		header2 = @acao_data.first.slice(@first_column,  @cols)
		header += header2
		arr = a1.map do |row|
			acao = (@acao_data.select{|s| s[0]==row.first.to_i}.first rescue nil)		
			puts "Cidades: #{@cities_obj.count} de #{@acao_data.count}"
			begin
				ss = acao.slice(@first_column,  @cols)
				row += ss
				c = {id: row[0], uf: row[2], cidade: row[3]}
				header2.each_with_index{|r, i| c[r]=ss[i]}
				c.merge! @coords[c[:id]]
				@cities_obj.push c 
				row
			rescue
				row
			end
		
		end
		#binding.pry
		@output_dbf = arr
		export_data_csv
		prepend_header(header)
	end

	def export_data_csv
		CSV.open("55mu2500gsr.csv.tmp", "w", {:col_sep => "\t"}) do |csv|
			@output_dbf.each do |row|
				if row
					csv << row
				end
			end
		end
	end

	def export_states_json
		puts "Exportando estados"
		s = @states_obj.to_json
		File.open("states.json","w") do |f|
		  f.write(s)
		end
	end

	def export_cities_json
		puts "Exportando cidades"
		s = @cities_obj.to_json
		File.open("cities.json","w") do |f|
		  f.write(s)
		end
	end

	def prepend_header(h)
		file_to_read = '55mu2500gsr.csv.tmp' 
		header = h.join("\t") + "\n"
		file = IO.read(file_to_read) 
		open("55mu2500gsr.csv", 'w') { |f| f << header << file} 
	end
end

m = MapImporter.new(source_dbf, acao_data, location_csv, states_csv)
m.work

